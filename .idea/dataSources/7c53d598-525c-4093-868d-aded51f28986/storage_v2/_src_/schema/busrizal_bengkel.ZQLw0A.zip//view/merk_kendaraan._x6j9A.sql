CREATE VIEW merk_kendaraan AS
  SELECT `busrizal_bengkel`.`kendaraan`.`merk` AS `merk`
  FROM `busrizal_bengkel`.`kendaraan`
  GROUP BY `busrizal_bengkel`.`kendaraan`.`merk`
  UNION SELECT 'other' AS `other`;

